#ifndef UTIL_H
#define UTIL_H

#include "matrix.h"

int util( matrix_t * eqs );

#endif
