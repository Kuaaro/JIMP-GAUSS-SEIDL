#ifndef MAKESPL_H
#define MAKESPL_H

#include "points.h"
#include "splines.h"


void  make_spl ( points_t *pts, spline_t *spl);

#endif
